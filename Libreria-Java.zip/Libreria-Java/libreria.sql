-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-04-2026 a las 10:43:23
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autores`
--

CREATE TABLE `autores` (
  `ID_AUTOR` bigint(20) UNSIGNED NOT NULL,
  `NOMBRE_AUTOR` varchar(255) NOT NULL,
  `CORREO_AUTOR` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `autores`
--

INSERT INTO `autores` (`ID_AUTOR`, `NOMBRE_AUTOR`, `CORREO_AUTOR`, `created_at`, `updated_at`) VALUES
(1, 'Gabriel García Márquez', 'garcia.marquez@email.com', '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(2, 'Isabel Allende', 'isabel.allende@email.com', '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(3, 'Mario Vargas Llosa', 'vargas.llosa@email.com', '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(4, 'Bryan', 'lopez@gmail.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `ID_LIBRO` bigint(20) UNSIGNED NOT NULL,
  `TITULO_LIBRO` varchar(255) NOT NULL,
  `ANIO_LIBRO` year(4) NOT NULL,
  `AUTOR_ID_PER` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`ID_LIBRO`, `TITULO_LIBRO`, `ANIO_LIBRO`, `AUTOR_ID_PER`, `created_at`, `updated_at`) VALUES
(1, 'Cien años de soledad', '1967', 1, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(2, 'El amor en los tiempos del cólera', '1985', 1, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(3, 'La casa de los espíritus', '1982', 2, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(4, 'Eva Luna', '1987', 2, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(5, 'La ciudad y los perros', '1963', 3, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(6, 'La fiesta del chivo', '2000', 3, '2026-04-15 08:14:36', '2026-04-15 08:14:36'),
(7, 'classroom', '2026', 4, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autores`
--
ALTER TABLE `autores`
  ADD PRIMARY KEY (`ID_AUTOR`),
  ADD UNIQUE KEY `CORREO_AUTOR` (`CORREO_AUTOR`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ID_LIBRO`),
  ADD KEY `fk_libros_autor` (`AUTOR_ID_PER`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autores`
--
ALTER TABLE `autores`
  MODIFY `ID_AUTOR` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `ID_LIBRO` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `libros`
--
ALTER TABLE `libros`
  ADD CONSTRAINT `fk_libros_autor` FOREIGN KEY (`AUTOR_ID_PER`) REFERENCES `autores` (`ID_AUTOR`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

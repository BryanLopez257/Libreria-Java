/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.libreria.java;

/**
 *
 * @author bl250
 */
public class LibreriaJava {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

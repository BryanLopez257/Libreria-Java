/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria.java;

/**
 *
 * @author bl250
 */
public class Libro {
    private String ID_LIBRO;
    private String TITULO_LIBRO;
    private String AUTOR;
    private String ANIO_LIBRO;
    private String AUTOR_ID_PER;

    public String getAUTOR_ID_PER() {
        return AUTOR_ID_PER;
    }

    public void setAUTOR_ID_PER(String AUTOR_ID_PER) {
        this.AUTOR_ID_PER = AUTOR_ID_PER;
    }

    public Libro(String ID_LIBRO, String TITULO_LIBRO, String AUTOR_ID_PER, String ANIO_LIBRO) {
        this.ID_LIBRO = ID_LIBRO;
        this.TITULO_LIBRO = TITULO_LIBRO;
        this.ANIO_LIBRO = ANIO_LIBRO;
        this.AUTOR_ID_PER = AUTOR_ID_PER;
    }

    public Libro() {

    }

    public String getID_LIBRO() {
        return ID_LIBRO;
    }

    public void setID_LIBRO(String ID_LIBRO) {
        this.ID_LIBRO = ID_LIBRO; // <--- CORREGIDO
    }

    public String getTITULO_LIBRO() {
        return TITULO_LIBRO;
    }

    public void setTITULO_LIBRO(String TITULO_LIBRO) {
        this.TITULO_LIBRO = TITULO_LIBRO;
    }

    public String getAUTOR() {
        return AUTOR;
    }

    public void setAUTOR(String AUTOR) {
        this.AUTOR = AUTOR;
    }

    public String getANIO_LIBRO() {
        return ANIO_LIBRO;
    }

    public void setANIO_LIBRO(String ANIO_LIBRO) {
        this.ANIO_LIBRO = ANIO_LIBRO;
    }
}

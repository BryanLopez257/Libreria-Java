/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.libreria.java;

import java.util.ArrayList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author FISEI-LB2
 */
public class Interfaz extends javax.swing.JFrame {

    ClienteAutores clienteAutores;
    DefaultTableModel modelo;
    ClienteLibros clienteLibros;
    DefaultTableModel modeloLibros;

    public Interfaz() {
        initComponents();
        clienteAutores = new ClienteAutores();
        clienteLibros = new ClienteLibros();
        cargarTablaAutores();
        cargarTablaLibros();
        cargarComboAutores(); // <--- DESCOMENTADO

        seleccionarAutor();
        seleccionarLibro(); // <--- AÑADIDO
    }

    public void cargarTablaAutores() {
    String[] titulos = {"ID", "NOMBRE", "CORREO"};
    String[] registro = new String[3];
    ArrayList<Autor> autores = clienteAutores.obtenerAutores();
    
    modelo = new DefaultTableModel(null, titulos);
    
    // VALIDACIÓN CRUCIAL
    if (autores != null) {
        for (Autor autor : autores) {
            registro[0] = autor.getID_AUTOR();
            registro[1] = autor.getNOMBRE_AUTOR();
            registro[2] = autor.getCORREO_AUTOR();
            modelo.addRow(registro);
        }
    } else {
        System.out.println("Aviso: No se pudieron obtener autores del servidor.");
    }
    jtblAutores.setModel(modelo);
}

    
    public void buscarAutor() {
    String id = jtxtBuscarAutores.getText();
    String[] titulos = {"ID", "NOMBRE", "CORREO"};
    String[] registro = new String[3];
    ArrayList<Autor> autores = clienteAutores.buscarAutores(id);
    
    modelo = new DefaultTableModel(null, titulos);
    
    // AGREGA ESTA VALIDACIÓN PARA EVITAR EL CRASH
    if (autores != null) {
        for (Autor autor : autores) {
            registro[0] = autor.getID_AUTOR();
            registro[1] = autor.getNOMBRE_AUTOR();
            registro[2] = autor.getCORREO_AUTOR();
            modelo.addRow(registro);
        }
    } else {
        System.out.println("No se encontró el autor o error de conexión.");
    }
    jtblAutores.setModel(modelo);
}

    public void guardarAutor() {
        String id = jtxtIdAutor.getText();
        String nombre = jtxtNombreAutor.getText();
        String correo = jtxtCorreoAutor.getText();

        Autor autor = new Autor(id, nombre, correo);

        if (clienteAutores.insertarAutores(autor)) {
            cargarTablaAutores();
        }
    }

    public void editarAutor() {
        String id = jtxtIdAutor.getText();
        String nombre = jtxtNombreAutor.getText();
        String correo = jtxtCorreoAutor.getText();

        Autor autor = new Autor(id, nombre, correo);

        if (clienteAutores.editarAutor(autor)) {
            cargarTablaAutores();
        }
    }

    public void eliminarAutor() {
        String id = jtxtIdAutor.getText();
        if (clienteAutores.eliminarAutor(id)) {
            cargarTablaAutores();
        }
    }

    public void cargarTablaLibros() {
    String[] titulos = {"ID", "TITULO", "AUTOR", "AÑO"};
    String[] registro = new String[4];
    ArrayList<Libro> libros = clienteLibros.obtenerLibros();
    
    modeloLibros = new DefaultTableModel(null, titulos);
    
    if (libros != null) {
        for (Libro libro : libros) {
            registro[0] = libro.getID_LIBRO();
            registro[1] = libro.getTITULO_LIBRO();
            registro[2] = libro.getAUTOR();
            registro[3] = libro.getANIO_LIBRO();
            modeloLibros.addRow(registro);
        }
    }
    jtblLibros.setModel(modeloLibros);
}

    public void buscarLibro() {
        String titulo = jtxtBuscarAutores1.getText();
        String[] titulos = {"ID", "TITULO", "AUTOR", "AÑO"};
        String[] registro = new String[4];
        ArrayList<Libro> libros = clienteLibros.buscarLibro(titulo);
        modeloLibros = new DefaultTableModel(null, titulos);
        for (Libro libro : libros) {
            registro[0] = libro.getID_LIBRO();
            registro[1] = libro.getTITULO_LIBRO();
            registro[2] = libro.getAUTOR();
            registro[3] = libro.getANIO_LIBRO();
            modeloLibros.addRow(registro);
        }
        jtblLibros.setModel(modeloLibros);
    }

    public void guardarLibro() {
        // Asumo que tus campos de texto de libro se llaman así:
        String id = jtxtIdLibro.getText();
        String titulo = jtxtTituloLibro.getText();
        String anio = jtxtAnioLibro.getText();

        // 1. Obtener el objeto Autor SELECCIONADO del ComboBox
        Autor autorSeleccionado = (Autor) jcboxAutor.getSelectedItem();

        // 2. Obtener el ID de ese autor
        String idAutor = autorSeleccionado.getID_AUTOR();

        // 3. Crear el objeto Libro
        // (Asumo que tu clase Libro tiene estos setters)
        Libro libro = new Libro();
        libro.setID_LIBRO(id);
        libro.setTITULO_LIBRO(titulo);
        libro.setAUTOR_ID_PER(idAutor); // <-- ID del autor
        libro.setANIO_LIBRO(anio);

        // 4. Llamar al clienteLibros
        if (clienteLibros.insertarLibros(libro)) {
            cargarTablaLibros();
            cargarComboAutores(); // Recarga por si acaso
        }
    }

    public void editarLibro() {
        String id = jtxtIdLibro.getText();
        String titulo = jtxtTituloLibro.getText();
        String anio = jtxtAnioLibro.getText();

        // 1. Obtener el objeto Autor SELECCIONADO
        Autor autorSeleccionado = (Autor) jcboxAutor.getSelectedItem();
        String idAutor = autorSeleccionado.getID_AUTOR();

        // 2. Crear el objeto Libro
        Libro libro = new Libro();
        libro.setID_LIBRO(id);
        libro.setTITULO_LIBRO(titulo);
        libro.setAUTOR_ID_PER(idAutor);
        libro.setANIO_LIBRO(anio);

        // 3. Llamar al clienteLibros
        if (clienteLibros.editarLibro(libro)) {
            cargarTablaLibros();
        }
    }

    public void eliminarLibro() {
        // 1. Obtener el ID del campo de texto de LIBRO
        String id = jtxtIdLibro.getText();

        // 2. Llamar al clienteLibros
        if (clienteLibros.eliminarLibro(id)) {
            cargarTablaLibros();
        }
    }

    public void seleccionarAutor() {
        jtblAutores.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Evita que se ejecute dos veces (al presionar y al soltar el clic)
                if (jtblAutores.getSelectedRow() != -1) {

                    int fila = jtblAutores.getSelectedRow();

                    // Obtenemos los nombres y la cantidad de la tabla
                    // Asumiendo tu carga: Col 2=CLIENTE, Col 3=PRODUCTO, Col 4=CANTIDAD
                    String id = jtblAutores.getValueAt(fila, 0).toString();
                    String nombre = jtblAutores.getValueAt(fila, 1).toString();
                    String correo = jtblAutores.getValueAt(fila, 2).toString();

                    // 1. Cargar el TextField (Esto ya lo tenías)
                    jtxtIdAutor.setText(id.trim());
                    jtxtCorreoAutor.setText(correo.trim());
                    jtxtNombreAutor.setText(nombre.trim());

                }
            }
        });
    }

    public void seleccionarLibro() {
        jtblLibros.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Evita que se ejecute dos veces (al presionar y al soltar el clic)
                if (jtblLibros.getSelectedRow() != -1) {

                    int fila = jtblLibros.getSelectedRow();

                    String id = jtblLibros.getValueAt(fila, 0).toString();
                    String titulo = jtblLibros.getValueAt(fila, 1).toString();
                    String autor = jtblLibros.getValueAt(fila, 2).toString();
                    String año = jtblLibros.getValueAt(fila, 3).toString();

                    // 1. Cargar el TextField (Esto ya lo tenías)
                    jtxtIdLibro.setText(id.trim());
                    jtxtTituloLibro.setText(titulo.trim());
                    //jcboxAutor.setText(autor.trim());
                    jtxtAnioLibro.setText(año.trim());

                }
            }
        });
    }

    public void cargarComboAutores() {
        // Asumo que tu JComboBox se llama jcboxAutor
        jcboxAutor.removeAllItems(); // Limpia el combo

        ArrayList<Autor> autores = clienteAutores.obtenerAutores();

        if (autores != null) {
            for (Autor autor : autores) {
                // Añadimos el OBJETO Autor completo.
                // Gracias al método toString() que añadiste, se verá el nombre.
                jcboxAutor.addItem(autor);
            }
        }
    }

    /*
                public void seleccionarAutor() {
        jtblAutores.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Evita que se ejecute dos veces (al presionar y al soltar el clic)
                if (jtblAutores.getSelectedRow() != -1) {

                    int fila = jtblAutores.getSelectedRow();

                    // Obtenemos los nombres y la cantidad de la tabla
                    // Asumiendo tu carga: Col 2=CLIENTE, Col 3=PRODUCTO, Col 4=CANTIDAD
                    String nombreCliente = jtblAutores.getValueAt(fila, 2).toString();
                    String nombreProducto = jtblAutores.getValueAt(fila, 3).toString();
                    String cantidad = jtblAutores.getValueAt(fila, 4).toString();

                    // 1. Cargar el TextField (Esto ya lo tenías)
                    jtxtCantidadVenta.setText(cantidad.trim());

                    // 2. Cargar los ComboBoxes usando un método auxiliar
                    seleccionarItemEnComboBox(jcboxClientes, nombreCliente);
                    seleccionarItemEnComboBox(jcboxProductos, nombreProducto);
                }
            }
        });
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtblAutores = new javax.swing.JTable();
        jbtnBuscarAutores = new javax.swing.JButton();
        jtxtBuscarAutores = new javax.swing.JTextField();
        jtxtIdAutor = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtxtNombreAutor = new javax.swing.JTextField();
        jtxtCorreoAutor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jbtnGuardar = new javax.swing.JButton();
        jtbnEditar = new javax.swing.JButton();
        jbtnEliminar = new javax.swing.JButton();
        jtxtAnioLibro = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtblLibros = new javax.swing.JTable();
        jbtnLibros = new javax.swing.JButton();
        jbtnGuardar1 = new javax.swing.JButton();
        jbtnBuscarAutores1 = new javax.swing.JButton();
        jtbnEditar1 = new javax.swing.JButton();
        jtxtBuscarAutores1 = new javax.swing.JTextField();
        jbtnEliminar1 = new javax.swing.JButton();
        jtxtIdLibro = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jtxtTituloLibro = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jcboxAutor = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtblAutores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jtblAutores);

        jbtnBuscarAutores.setText("Buscar");
        jbtnBuscarAutores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnBuscarAutoresActionPerformed(evt);
            }
        });

        jLabel1.setText("Correo");

        jLabel2.setText("ID");

        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Autores");

        jButton1.setText("Mostrar Autores");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jbtnGuardar.setText("Guardar");
        jbtnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnGuardarActionPerformed(evt);
            }
        });

        jtbnEditar.setText("Editar");
        jtbnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtbnEditarActionPerformed(evt);
            }
        });

        jbtnEliminar.setText("Eliminar");
        jbtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEliminarActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Libros");

        jtblLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jtblLibros);

        jbtnLibros.setText("Mostrar Libros");
        jbtnLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnLibrosActionPerformed(evt);
            }
        });

        jbtnGuardar1.setText("Guardar");
        jbtnGuardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnGuardar1ActionPerformed(evt);
            }
        });

        jbtnBuscarAutores1.setText("Buscar");
        jbtnBuscarAutores1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnBuscarAutores1ActionPerformed(evt);
            }
        });

        jtbnEditar1.setText("Editar");
        jtbnEditar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtbnEditar1ActionPerformed(evt);
            }
        });

        jbtnEliminar1.setText("Eliminar");
        jbtnEliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEliminar1ActionPerformed(evt);
            }
        });

        jLabel6.setText("Año");

        jLabel7.setText("ID");

        jLabel8.setText("Tìtulo");

        jLabel9.setText("Autor");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jtxtIdAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38)
                                .addComponent(jbtnGuardar))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jtxtNombreAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(46, 46, 46)
                                    .addComponent(jtbnEditar))
                                .addComponent(jbtnEliminar))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jtxtCorreoAutor, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jtxtBuscarAutores, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jbtnBuscarAutores)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jtxtIdLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(38, 38, 38)
                                        .addComponent(jbtnGuardar1))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jtxtTituloLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(46, 46, 46)
                                            .addComponent(jtbnEditar1))
                                        .addComponent(jbtnEliminar1))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jtxtBuscarAutores1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)
                                .addComponent(jbtnBuscarAutores1)
                                .addGap(18, 18, 18)
                                .addComponent(jbtnLibros))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jcboxAutor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jtxtAnioLibro, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(112, 112, 112))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(103, 103, 103))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(13, 13, 13)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(jtxtIdAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(16, 16, 16)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(jtxtNombreAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jbtnGuardar)
                                .addGap(18, 18, 18)
                                .addComponent(jtbnEditar)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jtxtCorreoAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtnEliminar))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbtnBuscarAutores)
                            .addComponent(jtxtBuscarAutores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(13, 13, 13)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(jtxtIdLibro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(16, 16, 16)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(jtxtTituloLibro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jbtnGuardar1)
                                .addGap(18, 18, 18)
                                .addComponent(jtbnEditar1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jtxtAnioLibro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtnEliminar1))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jcboxAutor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbtnBuscarAutores1)
                            .addComponent(jtxtBuscarAutores1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtnLibros))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnBuscarAutoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnBuscarAutoresActionPerformed
        buscarAutor();
    }//GEN-LAST:event_jbtnBuscarAutoresActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cargarTablaAutores();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jbtnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnGuardarActionPerformed
        guardarAutor();
    }//GEN-LAST:event_jbtnGuardarActionPerformed

    private void jtbnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtbnEditarActionPerformed
        editarAutor();
    }//GEN-LAST:event_jtbnEditarActionPerformed

    private void jbtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEliminarActionPerformed
        eliminarAutor();
    }//GEN-LAST:event_jbtnEliminarActionPerformed

    private void jbtnLibrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnLibrosActionPerformed
        cargarTablaLibros();
    }//GEN-LAST:event_jbtnLibrosActionPerformed

    private void jbtnGuardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnGuardar1ActionPerformed
        guardarLibro();
    }//GEN-LAST:event_jbtnGuardar1ActionPerformed

    private void jbtnBuscarAutores1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnBuscarAutores1ActionPerformed
        buscarLibro();
    }//GEN-LAST:event_jbtnBuscarAutores1ActionPerformed

    private void jtbnEditar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtbnEditar1ActionPerformed
        editarLibro();
    }//GEN-LAST:event_jtbnEditar1ActionPerformed

    private void jbtnEliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEliminar1ActionPerformed
        eliminarLibro();
    }//GEN-LAST:event_jbtnEliminar1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbtnBuscarAutores;
    private javax.swing.JButton jbtnBuscarAutores1;
    private javax.swing.JButton jbtnEliminar;
    private javax.swing.JButton jbtnEliminar1;
    private javax.swing.JButton jbtnGuardar;
    private javax.swing.JButton jbtnGuardar1;
    private javax.swing.JButton jbtnLibros;
    private javax.swing.JComboBox<Autor> jcboxAutor;
    private javax.swing.JTable jtblAutores;
    private javax.swing.JTable jtblLibros;
    private javax.swing.JButton jtbnEditar;
    private javax.swing.JButton jtbnEditar1;
    private javax.swing.JTextField jtxtAnioLibro;
    private javax.swing.JTextField jtxtBuscarAutores;
    private javax.swing.JTextField jtxtBuscarAutores1;
    private javax.swing.JTextField jtxtCorreoAutor;
    private javax.swing.JTextField jtxtIdAutor;
    private javax.swing.JTextField jtxtIdLibro;
    private javax.swing.JTextField jtxtNombreAutor;
    private javax.swing.JTextField jtxtTituloLibro;
    // End of variables declaration//GEN-END:variables
}

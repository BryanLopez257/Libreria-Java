/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria.java;

/**
 *
 * @author bl250
 */
public class Autor {
    private String ID_AUTOR;
    private String NOMBRE_AUTOR;
    private String CORREO_AUTOR;

    public Autor(String ID_AUTOR, String NOMBRE_AUTOR, String CORREO_AUTOR) {
        this.ID_AUTOR = ID_AUTOR;
        this.NOMBRE_AUTOR = NOMBRE_AUTOR;
        this.CORREO_AUTOR = CORREO_AUTOR;
    }

    public String getID_AUTOR() {
        return ID_AUTOR;
    }

    public String getNOMBRE_AUTOR() {
        return NOMBRE_AUTOR;
    }

    public void setNOMBRE_AUTOR(String NOMBRE_AUTOR) {
        this.NOMBRE_AUTOR = NOMBRE_AUTOR;
    }

    public String getCORREO_AUTOR() {
        return CORREO_AUTOR;
    }

    public void setCORREO_AUTOR(String CORREO_AUTOR) {
        this.CORREO_AUTOR = CORREO_AUTOR;
    }
    
    @Override
    public String toString() {
        return this.getNOMBRE_AUTOR(); // Muestra el nombre en el ComboBox
    }
}

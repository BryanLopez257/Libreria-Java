/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria.java;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

/**
 *
 * @author bl250
 */
public class ClienteAutores {
    private final String urlApi = "http://localhost/Libreria-Java/src/main/java/Apis/ApiAutores.php";
    private final Gson gson = new Gson();
    private final HttpClient cliente = HttpClient.newHttpClient();

    public ArrayList<Autor> obtenerAutores() {
        try {
            HttpRequest peticionGet = HttpRequest.newBuilder()
                    .uri(new URI(urlApi))
                    .GET()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionGet, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                String jsonAutores = respuesta.body();
                Type tipo = new TypeToken<ArrayList<Autor>>() {
                }.getType();
                ArrayList<Autor> autores = gson.fromJson(jsonAutores, tipo);
                return autores;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public ArrayList<Autor> buscarAutores(String id) {
        try {
            String urlBuscar = crearUrl("ID_AUTOR=" + id);
            HttpRequest peticionGet = HttpRequest.newBuilder()
                    .uri(new URI(urlBuscar))
                    .GET()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionGet, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                String jsonAutores = respuesta.body();
                Type tipo = new TypeToken<ArrayList<Autor>>() {
                }.getType();
                ArrayList<Autor> autores = gson.fromJson(jsonAutores, tipo);
                return autores;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public boolean insertarAutores(Autor autor) {
        try {
            String parametros = crearParametros(autor);
            HttpRequest peticionPost = HttpRequest.newBuilder()
                    .uri(new URI(urlApi))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(parametros))
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionPost, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean editarAutor(Autor autor) {
        try {
            String urlEditar = crearUrl(crearParametros(autor));
            HttpRequest peticionPut = HttpRequest.newBuilder()
                    .uri(new URI(urlEditar))
                    .PUT(HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionPut, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean eliminarAutor(String id) {
        try {
            String urlEliminar = crearUrl("ID_AUTOR=" + id);
            HttpRequest peticionDelete = HttpRequest.newBuilder()
                    .uri(new URI(urlEliminar))
                    .DELETE()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionDelete, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public String crearUrl(String parametros) {
        return urlApi + "?" + parametros;
    }

    public String crearParametros(Autor autor) {
        return "ID_AUTOR=" + autor.getID_AUTOR()
                + "&NOMBRE_AUTOR=" + autor.getNOMBRE_AUTOR()
                + "&CORREO_AUTOR=" + autor.getCORREO_AUTOR();
    }
}

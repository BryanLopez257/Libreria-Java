/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libreria.java;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

/**
 *
 * @author bl250
 */
public class ClienteLibros {
    private final String urlApi = "http://localhost/Libreria-Java/src/main/java/Apis/ApiLibros.php";
    private final Gson gson = new Gson();
    private final HttpClient cliente = HttpClient.newHttpClient();

    public ArrayList<Libro> obtenerLibros() {
        try {
            HttpRequest peticionGet = HttpRequest.newBuilder()
                    .uri(new URI(urlApi))
                    .GET()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionGet, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                String jsonLibros = respuesta.body();
                Type tipo = new TypeToken<ArrayList<Libro>>() { // <--- CORREGIDO
                }.getType();
                ArrayList<Libro> libros = gson.fromJson(jsonLibros, tipo);
                return libros;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public ArrayList<Libro> buscarLibro(String libro) {
        try {
            String urlBuscar = crearUrl("TITULO_LIBRO=" + libro);
            HttpRequest peticionGet = HttpRequest.newBuilder()
                    .uri(new URI(urlBuscar))
                    .GET()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionGet, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                String jsonLibros = respuesta.body();
                Type tipo = new TypeToken<ArrayList<Libro>>() {
                }.getType();
                ArrayList<Libro> libros = gson.fromJson(jsonLibros, tipo);
                return libros;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public boolean insertarLibros(Libro libro) {
        try {
            String parametros = crearParametros(libro);
            HttpRequest peticionPost = HttpRequest.newBuilder()
                    .uri(new URI(urlApi))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(parametros))
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionPost, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean editarLibro(Libro libro) {
        try {
            String urlEditar = crearUrl(crearParametros(libro));
            HttpRequest peticionPut = HttpRequest.newBuilder()
                    .uri(new URI(urlEditar))
                    .PUT(HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionPut, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public boolean eliminarLibro(String id) {
        try {
            String urlEliminar = crearUrl("ID_LIBRO=" + id);
            HttpRequest peticionDelete = HttpRequest.newBuilder()
                    .uri(new URI(urlEliminar))
                    .DELETE()
                    .build();
            HttpResponse<String> respuesta = cliente.send(peticionDelete, HttpResponse.BodyHandlers.ofString());

            if (respuesta.statusCode() == 200) {
                return true;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public String crearUrl(String parametros) {
        return urlApi + "?" + parametros;
    }

    public String crearParametros(Libro libro) {
        return "ID_LIBRO=" + libro.getID_LIBRO()
                + "&TITULO_LIBRO=" + libro.getTITULO_LIBRO()
                + "&AUTOR_ID_PER=" + libro.getAUTOR_ID_PER()
                + "&ANIO_LIBRO=" + libro.getANIO_LIBRO();
    }
}
